import { createContext, useContext, useState, ReactNode } from "react";

export interface DataRow {
  [key: string]: string | number;
}

export interface SheetData {
  name: string;
  columns: string[];
  rows: DataRow[];
}

export interface UploadedData {
  fileName: string;
  sheets: SheetData[]; // Multiple sheets
  uploadDate: Date;
}

interface DataContextType {
  data: UploadedData | null;
  setData: (data: UploadedData | null) => void;
  isDataLoaded: boolean;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<UploadedData | null>(null);

  return (
    <DataContext.Provider
      value={{
        data,
        setData,
        isDataLoaded: data !== null,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}