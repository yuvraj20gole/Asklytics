import { useState } from "react";
import { Link, useNavigate } from "react-router";

export function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password) {
      return;
    }

    // Simulate login
    navigate("/welcome");
  };

  const fillDemoCredentials = () => {
    setFormData({
      email: "analyst@example.com",
      password: "admin123"
    });
  };

  return (
    <div className="min-h-screen bg-[#ede8e0] px-4 py-6">
      {/* Top Header */}
      <div className="max-w-6xl mx-auto flex items-center justify-between mb-12">
        <Link to="/" className="text-2xl font-bold text-[#1e7a5c]" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
          Asklytics
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-gray-600 text-sm">No account?</span>
          <Link 
            to="/register" 
            className="px-4 py-2 bg-[#1e7a5c] text-white rounded-lg text-sm hover:bg-[#196a4f] transition-colors"
          >
            Register free
          </Link>
        </div>
      </div>

      {/* Login Card */}
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-3xl p-10 shadow-lg">
          {/* Logo */}
          <div className="text-center mb-6">
            <div className="text-2xl font-bold text-[#1e7a5c]" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
              Asklytics
            </div>
          </div>

          {/* Heading */}
          <h1 className="text-center text-3xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
            Welcome back
          </h1>
          <p className="text-center text-gray-600 mb-8">
            Log in to your Asklytics dashboard
          </p>

          {/* Demo Account Section */}
          <div className="bg-[#e8e4dc] rounded-xl p-5 mb-6">
            <div className="text-xs font-semibold text-gray-700 mb-3 tracking-wide">DEMO ACCOUNT</div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-sm text-gray-600">Email:</span>
                <span className="ml-2 text-sm font-medium">analyst@example.com</span>
              </div>
              <div>
                <span className="text-sm text-gray-600">Password:</span>
                <span className="ml-2 text-sm font-medium">admin123</span>
              </div>
            </div>
            <button
              type="button"
              onClick={fillDemoCredentials}
              className="w-full px-4 py-2 bg-[#d4f4e7] text-[#1e7a5c] rounded-lg text-sm font-medium hover:bg-[#c0edd9] transition-colors"
            >
              Fill demo credentials
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email or Username
              </label>
              <input
                type="text"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-[#e8e4dc] border-0 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e7a5c] text-gray-900 placeholder:text-gray-500"
                placeholder="you@company.com or username"
              />
            </div>

            {/* Password Input */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <Link to="#" className="text-sm text-[#1e7a5c] hover:underline">
                  Forgot password?
                </Link>
              </div>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-3 bg-[#e8e4dc] border-0 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e7a5c] text-gray-900 placeholder:text-gray-500"
                placeholder="Enter your password"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3 bg-[#1e7a5c] text-white rounded-lg hover:bg-[#196a4f] transition-colors font-medium text-base"
            >
              Log in to Asklytics →
            </button>
          </form>

          {/* Bottom Link */}
          <p className="text-center text-sm text-gray-600 mt-6">
            No account?{" "}
            <Link to="/register" className="text-[#1e7a5c] font-medium hover:underline">
              Register for free
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
